<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> 
<html class="no-js" <?php language_attributes(); ?>> <!--<![endif]-->
<head>
    <meta http-equiv="<?php echo get_template_directory_uri();?>/content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
    <title><?php wp_title('-');?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
    <?php
    global $teo_data;
    if(isset($teo_data['tracking-code']) && $teo_data['tracking-code'] != '') {
        echo $teo_data['tracking-code'];
    }
    if( teo_is_woo_active() ) { 
        global $woocommerce;
        $myaccount_page_id = get_option( 'woocommerce_myaccount_page_id' );
        $myaccount_page_url = get_permalink( $myaccount_page_id );
    }
    wp_head(); 
    ?>
</head>
<body <?php body_class();?>>
<div class="top-bar">
        <div class="container">
            <div class="row">
                <div class="col-sm-3 col-xs-4">
                    <?php teo_language_switcher();?>
                </div>
                <div class="col-sm-9 col-xs-8">
                    <div class="right-side">
                        <?php if( teo_is_woo_active() ) { ?>
                            <div class="cart-info">
                                <a href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'trendy'); ?>">
                                    <span class="counter"><?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'trendy'), $woocommerce->cart->cart_contents_count);?></span>
                                    <span class="separator">/</span>
                                    <span class="value"><?php echo $woocommerce->cart->get_cart_total(); ?></span>
                                </a>
                            </div>
                            <?php
                            if(is_user_logged_in() ) {
                                echo '<a class="btn btn-link" href="' . get_permalink( wc_get_page_id( 'shop' ) ) . '">' . __('Go To Shop', 'trendy') . '</a>';
                            }
                            else if($myaccount_page_url) { ?>
                                <a data-target="#login-modal" data-toggle="modal" class="btn btn-link" href="#"><?php _e('Login / Register', 'trendy');?></a>
                            <?php }
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="navbar navbar-default">
          <div class="container">
              <div class="row">
                  <div class="navbar-header col-sm-3">
                      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                      </button>
                      <a class="navbar-brand" href="<?php echo get_bloginfo('url');?>">
                            <span class="inner">
                                <?php
                                if(isset($cleanse_data['logo']) && $cleanse_data['logo']['url'] != '') {
                                    $logo = $cleanse_data['logo']['url'];
                                }
                                else {
                                    $logo = get_template_directory_uri() . '/content/logo.png';
                                }
                                ?>
                                <img src="<?php echo $logo;?>" alt="<?php bloginfo('name');?>" />
                          </span>
                      </a>
                  </div>
                <div class="col-sm-9 right-side">
                    <div class="navbar-collapse collapse">
                        <div class="row secondary-navigation-wrap">
                            <address>
                                <?php 
                                if(isset($teo_data['header_address']) && $teo_data['header_address'] != '') {
                                    echo $teo_data['header_address'];
                                }
                                ?>
                            </address>
                            <ul class="nav navbar-nav secondary-navigation">
                                <li><a href="<?php echo get_bloginfo('url');?>"><?php _e('Home', 'trendy');?></a></li>
                                <?php 
                                if( teo_is_woo_active() ) { 
                                    global $woocommerce;
                                    if ( $myaccount_page_url ) {
                                        echo '<li><a href="' . $myaccount_page_url . '">' . __('My Account', 'trendy') . '</a></li>';
                                    }
                                    ?>
                                    <li><a href="<?php echo $woocommerce->cart->get_cart_url(); ?>"><?php _e( 'Shopping Cart', 'trendy' ); ?></a></li>
                                    <li><a href="<?php echo $woocommerce->cart->get_checkout_url(); ?>"><?php _e( 'Checkout', 'trendy' ); ?></a></li>
                                <?php } ?>
                            </ul>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 main-navigation">
                                <?php wp_nav_menu(array(
                                    'theme_location' => 'top-menu',
                                    'container' => '',
                                    'fallback_cb' => 'show_top_menu',
                                    'menu_id' => 'menu-top-menu',
                                    'menu_class' => 'nav navbar-nav navbar-right',
                                    'echo' => true,
                                    'depth' => 0 ) );
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>