<?php 
/* 
Template name: Contact page template 
*/

get_header();
the_post(); 
$map = get_post_meta($post->ID, '_contact_map', true);
$title = get_post_meta($post->ID, '_contact_title', true);
$address = get_post_meta($post->ID, '_contact_address', true);
$phone = get_post_meta($post->ID, '_contact_phone', true);
?>

<?php if($map != '') { ?>
    <section class="map-container">
        <?php echo $map;?>
        <div class="address-info-wrap">
            <div class="address-info">
                <?php if($title != '') { ?>
                    <div class="name"><?php echo $title;?></div>
                <?php } ?>
                
                <?php if($address != '') { ?>
                    <address><?php echo $address;?></address>
                <?php } ?>
                
                <?php if($phone != '') { ?>
                    <div class="phone"><?php echo $phone;?></div>
                <?php } ?>

                <div class="overlay-map"></div>
            </div>
        </div>
    </section>
<?php } ?>
<section class="main-container">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">
                <div class="post">
                    <div class="contact-info text-editor">
                        <?php the_content();?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
<?php get_footer();?>