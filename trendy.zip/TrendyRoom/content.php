<?php
$categories = get_the_category();
$class = '';
if($categories && is_array($categories) ) {
    foreach($categories as $cat) {
        $class .= ' filter-' . $cat->slug;
    }
}
?>
<div class="col-sm-6 <?php echo $class;?>">
    <article <?php post_class();?>>
        <?php
        if(has_post_thumbnail() ) {
            $thumb = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
            $resized = teo_resize($thumb, 255, 255, true); ?>
            <figure>
                <a href="<?php the_permalink();?>">
                    <img src="<?php echo $resized;?>" alt="<?php the_title();?>" />
                </a>
            </figure>
        <?php } ?>
        <div class="article-content <?php if(!has_post_thumbnail() ) echo 'no-content'?>">
            <h3>
                <a href="<?php the_permalink();?>"><?php the_title();?></a>
            </h3>
            <div class="content">
                <?php echo wp_trim_words(get_the_content(), 14, '...');?>
            </div>
            <a class="read-more" href="<?php the_permalink();?>">
                <?php _e('Read more', 'trendy');?>
            </a>
            <a class="link" href="<?php the_permalink();?>"></a>
        </div>
    </article>
</div>