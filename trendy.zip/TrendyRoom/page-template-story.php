<?php 
/* 
Template name: Our Story page template 
*/
get_header();
the_post(); 
$image = get_post_meta($post->ID, '_ourstory_bgimage', true);
$quote = get_post_meta($post->ID, '_ourstory_quotetext', true);
$author = get_post_meta($post->ID, '_ourstory_quoteauthor', true);
$tabs = get_post_meta($post->ID, '_ourstory_tabs', true);
if($image != '') { ?>
    <section class="top-quote" style="background-image: url('<?php echo esc_url($image);?>')">
        <div class="story-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <?php if($quote != '') { ?>
                        <div class="top-quote-text"><?php echo $quote;?></div>
                    <?php } ?>

                    <?php if($author != '') { ?>
                        <div class="top-quote-author"><?php echo $author;?></div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </section>
<?php } ?>

<section class="tab-container">
    <div class="container">
        <div class="row text-center">
            <?php if(is_array($tabs) && count($tabs) > 0) { ?>
                <ul class="nav nav-tabs">
                    <?php
                    $i = 1;
                    foreach($tabs as $key => $entry) { 
                        $title = $entry['tab_title']; ?>
                        <li <?php if($i == 1) echo 'class="active"';?>><a href="#<?php echo sanitize_title_with_dashes($title);?>" data-toggle="tab"><?php echo $title;?></a></li>
                    <?php $i++; } ?>
                </ul>
            <?php } ?>
            <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">
                <div class="tab-content">
                    <?php 
                    if(is_array($tabs) && count($tabs) > 0) { 
                        $i = 1;
                        foreach($tabs as $key => $entry) { 
                            $title = $entry['tab_title'];
                            $text = $entry['tab_text'];
                        ?>
                        <div class="tab-pane text-editor <?php if($i == 1) echo 'active';?>" id="<?php echo sanitize_title_with_dashes($title);?>">
                            <?php echo $text;?>
                        </div>
                        <?php
                        $i++;
                        }
                    } 
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer();?>