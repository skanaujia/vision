<?php
/*
Template name: Shop page template
*/
the_post();
$categories = get_post_meta($post->ID, '_shop_categories', true);

get_header( 'shop' ); 
if( !teo_is_woo_active() ) {
	_e('You need to enable WooCommerce in order to use this page template', 'trendy');
}
else {
?>
	<div class="main-container">

		<div class="container">
			<div class="row">

				<div class="col-sm-12">
			        <div class="products-header">
			          	<div class="category-menu">
			                <span class="page-title"><?php the_title(); ?></span>
			            </div>
			        </div>
			    </div>

				<div class="col-sm-12">
					<div class="grid-products-wrapper">
						<div class="row">

							<?php 
							$args = array();
							$paged = is_front_page() ? get_query_var( 'page' ) : get_query_var( 'paged' );
	                    	$args['paged'] = $paged;
							$args['post_type'] = 'product';
							if(is_array($categories) && count($categories) > 0) {
								$args['tax_query'] = array(
									array( 
										'taxonomy' => 'product_cat',
										'terms' => $categories
									)
								);
							}

							query_posts($args);

							if ( have_posts() ) : ?>

								<?php while ( have_posts() ) : the_post(); ?>

									<?php wc_get_template_part( 'content', 'product' ); ?>

								<?php endwhile; // end of the loop. ?>

								<?php woocommerce_pagination();  ?>

							<?php elseif ( ! woocommerce_product_subcategories( array( 'before' => woocommerce_product_loop_start( false ), 'after' => woocommerce_product_loop_end( false ) ) ) ) : ?>

								<?php wc_get_template( 'loop/no-products-found.php' ); ?>

							<?php endif; wp_reset_query(); ?>
						</div>
					</div>
				</div>

			</div>

		</div>

	</div>

<?php }

get_footer( 'shop' ); ?>