<?php 
get_header();
the_post();
$format = get_post_format();
$video = get_post_meta($post->ID, '_single_video', true);
?>
<section class="main-container">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="post">
                    <h2><?php the_title();?></h2>
                    <div class="post-content text-editor">
                        <?php the_content();?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
<?php get_footer();?>