<?php
/**
 * Login form
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( is_user_logged_in() ) 
	return;
?>
<form method="post" class="login" <?php if ( $hidden ) echo 'style="display:none;"'; ?>>

	<?php do_action( 'woocommerce_login_form_start' ); ?>

	<div class="col-sm-12">
		<?php if ( $message ) echo wpautop( wptexturize( $message ) ); ?>
	</div>
	<div class="col-sm-6">
		<p class="form-row form-row-first">
			<label for="username"><?php _e( 'Username or email', 'trendy' ); ?> <span class="required">*</span></label>
			<input type="text" class="input-text" name="username" id="username" />
		</p>
	</div>

	<div class="col-sm-6">
		<p class="form-row form-row-last">
			<label for="password"><?php _e( 'Password', 'trendy' ); ?> <span class="required">*</span></label>
			<input class="input-text" type="password" name="password" id="password" />
		</p>
	</div>

	<div class="clear"></div>

	<?php do_action( 'woocommerce_login_form' ); ?>

	<div class="col-sm-12">
		<p class="form-row">
			<?php wp_nonce_field( 'woocommerce-login' ); ?>
			<input type="submit" class="btn btn-default checkout-btn" name="login" value="<?php _e( 'Login', 'trendy' ); ?>" />
			<input type="hidden" name="redirect" value="<?php echo esc_url( $redirect ) ?>" />
			<label for="rememberme" class="inline">
				<input name="rememberme" type="checkbox" id="rememberme" value="forever" /> <?php _e( 'Remember me', 'trendy' ); ?>
			</label>
		</p>

		<p class="lost_password">
			<a href="<?php echo esc_url( wc_lostpassword_url() ); ?>"><?php _e( 'Lost your password?', 'trendy' ); ?></a>
		</p>
	</div>

	<div class="clear"></div>

	<?php do_action( 'woocommerce_login_form_end' ); ?>

</form>