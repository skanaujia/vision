<?php
/**
 * The template for displaying alternative product content within loops.
 *
 *
 * @author      TeoThemes
 * @package     WooCommerce/Templates
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $product, $woocommerce_loop;

// Ensure visibility
if ( ! $product || ! $product->is_visible() )
    return;

// Extra post classes
?>
<article <?php post_class( 'product-description' ); ?>>
    <div class="product-slider">
        <ul class="slides">
            <?php
            $thumb = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
            $resized = teo_resize($thumb, 845, 420); 
            if($thumb != '') { ?>
                <li>
                    <figure>
                        <img src="<?php echo $resized;?>" alt="<?php the_title();?>" />
                    </figure>
                </li>
            <?php } 
            $attachment_ids = $product->get_gallery_attachment_ids();
            if ( $attachment_ids ) {
                foreach ( $attachment_ids as $attachment_id ) {
                    $thumb = wp_get_attachment_url( $attachment_id );
                    if($thumb != '') { 
                        $resized = teo_resize($thumb, 845, 420);
                    ?>
                        <li>
                            <figure>
                                <img src="<?php echo $resized;?>" alt="<?php echo get_the_title( $attachment_id ); ?>" />
                            </figure>
                        </li>
                    <?php }
                }
            }
            ?>
        </ul>
    </div>
    <div class="name"><?php the_title();?></div>
    <div class="right_area">
        <div itemprop="description" class="description">
            <?php echo wp_trim_words($post->post_excerpt, 35, '...'); ?>
        </div>
        <div class="price-wrapper">
            <a href="<?php the_permalink();?>">
                <span class="value"><?php echo $product->get_price_html(); ?></span>
                <span class="on-hover"><?php _e('View product', 'trendy');?></span>
            </a>
        </div>
    </div>
</article>