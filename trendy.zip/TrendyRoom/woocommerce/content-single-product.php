<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * Override this template by copying it to yourtheme/woocommerce/content-single-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

<?php
	/**
	 * woocommerce_before_single_product hook
	 *
	 * @hooked wc_print_notices - 10
	 */
	 do_action( 'woocommerce_before_single_product' );

	 if ( post_password_required() ) {
	 	echo get_the_password_form();
	 	return;
	 }
global $product;
?>

<div itemscope itemtype="<?php echo woocommerce_get_product_schema(); ?>" id="product-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="col-sm-12">
		<div class="product-description">
			<div class="product-slider">
				<ul class="slides">
					<?php
					$thumb = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
					$resized = teo_resize($thumb, 845, 420); 
					if($thumb != '') { ?>
						<li>
							<figure>
								<img src="<?php echo $resized;?>" alt="<?php the_title();?>" />
							</figure>
						</li>
					<?php } 
					$attachment_ids = $product->get_gallery_attachment_ids();
					if ( $attachment_ids ) {
						foreach ( $attachment_ids as $attachment_id ) {
							$thumb = wp_get_attachment_url( $attachment_id );
							if($thumb != '') { 
								$resized = teo_resize($thumb, 845, 420);
							?>
								<li>
									<figure>
										<img src="<?php echo $resized;?>" alt="<?php echo get_the_title( $attachment_id ); ?>" />
									</figure>
								</li>
							<?php }
						}
					}
					?>
				</ul>
			</div>
			<div class="name"><?php the_title();?></div>
			<div class="right_area">
				<?php woocommerce_template_single_excerpt(); // woocommerce/short-description.php ?>
				<?php //woocommerce_template_single_rating(); ?>
				<?php woocommerce_template_single_price();?>
				<?php woocommerce_template_single_add_to_cart();?>
			</div>
		</div>
	</div>

	<div class="col-sm-12">
        <div class="product-presentation-tabs">
            <?php woocommerce_output_product_data_tabs();?>
        </div>
    </div>

    <?php comments_template(); ?> 
    
    <div class="col-sm-12">
        <div class="recommended-products grid-products-wrapper">
        	<?php woocommerce_output_related_products(); ?>
        </div>
    </div>

	<meta itemprop="url" content="<?php the_permalink(); ?>" />

</div><!-- #product-<?php the_ID(); ?> -->

<?php do_action( 'woocommerce_after_single_product' ); ?>
