<?php
/**
 * Review order table
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
	<div class="price-info">
        <ul>
			<li>
				<div class="for product-name"><?php _e( 'Product', 'trendy' ); ?></div>
				<div class="price product-total"><?php _e( 'Total', 'trendy' ); ?></div>
			</li>

			<?php
				do_action( 'woocommerce_review_order_before_cart_contents' );

				foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
					$_product     = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );

					if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_checkout_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
						?>
						<li class="<?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
							<div class="for product-name">
								<?php echo apply_filters( 'woocommerce_cart_item_name', $_product->get_title(), $cart_item, $cart_item_key ); ?>
								<?php echo apply_filters( 'woocommerce_checkout_cart_item_quantity', ' <strong class="product-quantity">' . sprintf( '&times; %s', $cart_item['quantity'] ) . '</strong>', $cart_item, $cart_item_key ); ?>
								<?php echo WC()->cart->get_item_data( $cart_item ); ?>
							</div>
							<div class="price product-total">
								<?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); ?>
							</div>
						</li>
						<?php
					}
				}

				do_action( 'woocommerce_review_order_after_cart_contents' );
			?>

			<li class="cart-subtotal">
				<div class="for"><?php _e( 'Cart Subtotal', 'trendy' ); ?></div>
				<div class="price"><?php wc_cart_totals_subtotal_html(); ?></div>
			</li>

			<?php foreach ( WC()->cart->get_coupons( 'cart' ) as $code => $coupon ) : ?>
				<li class="cart-discount coupon-<?php echo esc_attr( $code ); ?>">
					<div class="for"><?php wc_cart_totals_coupon_label( $coupon ); ?></div>
					<div class="price"><?php wc_cart_totals_coupon_html( $coupon ); ?></div>
				</li>
			<?php endforeach; ?>

			<?php if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) : ?>

				<?php do_action( 'woocommerce_review_order_before_shipping' ); ?>

				<?php wc_cart_totals_shipping_html(); ?>

				<?php do_action( 'woocommerce_review_order_after_shipping' ); ?>

			<?php endif; ?>

			<?php foreach ( WC()->cart->get_fees() as $fee ) : ?>
				<li class="fee">
					<div class="for"><?php echo esc_html( $fee->name ); ?></div>
					<div class="price"><?php wc_cart_totals_fee_html( $fee ); ?></div>
				</li>
			<?php endforeach; ?>

			<?php if ( WC()->cart->tax_display_cart === 'excl' ) : ?>
				<?php if ( get_option( 'woocommerce_tax_total_display' ) === 'itemized' ) : ?>
					<?php foreach ( WC()->cart->get_tax_totals() as $code => $tax ) : ?>
						<li class="tax-rate tax-rate-<?php echo sanitize_title( $code ); ?>">
							<div class="for"><?php echo esc_html( $tax->label ); ?></div>
							<div class="price"><?php echo wp_kses_post( $tax->formatted_amount ); ?></div>
						</li>
					<?php endforeach; ?>
				<?php else : ?>
					<li class="tax-total">
						<div class="for"><?php echo esc_html( WC()->countries->tax_or_vat() ); ?></div>
						<div class="price"><?php echo wc_price( WC()->cart->get_taxes_total() ); ?></div>
					</li>
				<?php endif; ?>
			<?php endif; ?>

			<?php foreach ( WC()->cart->get_coupons( 'order' ) as $code => $coupon ) : ?>
				<li class="order-discount coupon-<?php echo esc_attr( $code ); ?>">
					<div class="for"><?php wc_cart_totals_coupon_label( $coupon ); ?></div>
					<div class="price"><?php wc_cart_totals_coupon_html( $coupon ); ?></div>
				</li>
			<?php endforeach; ?>

			<?php do_action( 'woocommerce_review_order_before_order_total' ); ?>

			<li class="order-total">
				<div class="for"><?php _e( 'Order Total', 'trendy' ); ?></div>
				<div class="price"><?php wc_cart_totals_order_total_html(); ?></div>
			</li>

			<?php do_action( 'woocommerce_review_order_after_order_total' ); ?>
		</ul>
	</div>