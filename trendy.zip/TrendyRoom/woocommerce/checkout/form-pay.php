<?php
/**
 * Pay for order form
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $woocommerce;
?>
<form id="order_review" method="post">

	<div class="col-sm-6">

		<div class="shopping-container thankyou">
			<ul class="order_details price-info">
				<li class="order">
					<div class="for product-name"><?php _e( 'Product', 'trendy' ); ?></div>
					<div class="price product-total"><?php _e( 'Totals', 'trendy' ); ?></div>
				</li>
				<?php
					if ( $totals = $order->get_order_item_totals() ) foreach ( $totals as $total ) :
						?>
						<li>
							<div class="for"><?php echo $total['label']; ?></div>
							<div class="price"><?php echo $total['value']; ?></div>
						</li>
						<?php
					endforeach;
				?>
				<?php
				if ( sizeof( $order->get_items() ) > 0 ) :
					foreach ( $order->get_items() as $item ) :
						echo '
							<li>
								<div class="for product-name">' . $item['name'] . ' * ' . $item['qty'] . '</div>
								<div class="price product-subtotal">' . $order->get_formatted_line_subtotal( $item ) . '</div>
							</li>';
					endforeach;
				endif;
				?>
			</ul>
		</div>
	</div>

	<div class="col-sm-6">

		<div id="payment">
			<?php if ( $order->needs_payment() ) : ?>
			<h3><?php _e( 'Payment', 'trendy' ); ?></h3>
			<ul class="payment_methods methods">
				<?php
					if ( $available_gateways = WC()->payment_gateways->get_available_payment_gateways() ) {
						// Chosen Method
						if ( sizeof( $available_gateways ) )
							current( $available_gateways )->set_current();

						foreach ( $available_gateways as $gateway ) {
							?>
							<li class="payment_method_<?php echo $gateway->id; ?>">
								<input id="payment_method_<?php echo $gateway->id; ?>" type="radio" class="input-radio" name="payment_method" value="<?php echo esc_attr( $gateway->id ); ?>" <?php checked( $gateway->chosen, true ); ?> data-order_button_text="<?php echo esc_attr( $gateway->order_button_text ); ?>" />
								<label for="payment_method_<?php echo $gateway->id; ?>"><?php echo $gateway->get_title(); ?> <?php echo $gateway->get_icon(); ?></label>
								<?php
									if ( $gateway->has_fields() || $gateway->get_description() ) {
										echo '<div class="payment_box payment_method_' . $gateway->id . '" style="display:none;">';
										$gateway->payment_fields();
										echo '</div>';
									}
								?>
							</li>
							<?php
						}
					} else {

						echo '<p>' . __( 'Sorry, it seems that there are no available payment methods for your location. Please contact us if you require assistance or wish to make alternate arrangements.', 'trendy' ) . '</p>';

					}
				?>
			</ul>
			<?php endif; ?>

			<div class="form-row">
				<?php wp_nonce_field( 'woocommerce-pay' ); ?>
				<?php
					$pay_order_button_text = apply_filters( 'woocommerce_pay_order_button_text', __( 'Pay for order', 'trendy' ) );
					
					echo apply_filters( 'woocommerce_pay_order_button_html', '<input type="submit" class="button alt" id="place_order" value="' . esc_attr( $pay_order_button_text ) . '" data-value="' . esc_attr( $pay_order_button_text ) . '" />' );
				?>			
				<input type="hidden" name="woocommerce_pay" value="1" />
			</div>

		</div>
		
	</div>

</form>
