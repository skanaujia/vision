<?php
/**
 * Thankyou page
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( $order ) : ?>

<div class="col-sm-12">

	<?php if ( $order->has_status( 'failed' ) ) : ?>

		<p><?php _e( 'Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction.', 'trendy' ); ?></p>

		<p><?php
			if ( is_user_logged_in() )
				_e( 'Please attempt your purchase again or go to your account page.', 'trendy' );
			else
				_e( 'Please attempt your purchase again.', 'trendy' );
		?></p>

		<p>
			<a href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>" class="button pay"><?php _e( 'Pay', 'trendy' ) ?></a>
			<?php if ( is_user_logged_in() ) : ?>
			<a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'myaccount' ) ) ); ?>" class="button pay"><?php _e( 'My Account', 'trendy' ); ?></a>
			<?php endif; ?>
		</p>

	<?php else : ?>

		<p><?php echo apply_filters( 'woocommerce_thankyou_order_received_text', __( 'Thank you. Your order has been received.', 'trendy' ), $order ); ?></p>

		<div class="shopping-container thankyou">
			<ul class="order_details price-info">
				<li class="order">
					<div class="for"><?php _e( 'Order:', 'trendy' ); ?></div>
					<div class="price"><strong><?php echo $order->get_order_number(); ?></strong></div>
				</li>
				<li class="date">
					<div class="for"><?php _e( 'Date:', 'trendy' ); ?></div>
					<div class="price"><strong><?php echo date_i18n( get_option( 'date_format' ), strtotime( $order->order_date ) ); ?></strong></div>
				</li>
				<li class="total">
					<div class="for"><?php _e( 'Total:', 'trendy' ); ?></div>
					<div class="price"><strong><?php echo $order->get_formatted_order_total(); ?></strong></div>
				</li>
				<?php if ( $order->payment_method_title ) : ?>
				<li class="method">
					<div class="for"><?php _e( 'Payment method:', 'trendy' ); ?></div>
					<div class="price"><strong><?php echo $order->payment_method_title; ?></strong></div>
				</li>
				<?php endif; ?>
			</ul>
		</div>
		<div class="clear"></div>

	<?php endif; ?>

	<?php do_action( 'woocommerce_thankyou_' . $order->payment_method, $order->id ); ?>
	<?php do_action( 'woocommerce_thankyou', $order->id ); ?>

<?php else : ?>

	<p><?php echo apply_filters( 'woocommerce_thankyou_order_received_text', __( 'Thank you. Your order has been received.', 'trendy' ), null ); ?></p>

<?php endif; ?>

</div>