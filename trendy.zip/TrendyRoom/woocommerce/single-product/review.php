<?php
/**
 * Review Comments Template
 *
 * Closing li is left out on purpose!
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$rating = intval( get_comment_meta( $comment->comment_ID, 'rating', true ) );
?>
<li itemprop="reviews" itemscope itemtype="http://schema.org/Review" <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">

	<div id="comment-<?php comment_ID(); ?>" class="comment_container">

		<figure>
			<?php echo get_avatar( $comment, apply_filters( 'woocommerce_review_gravatar_size', '128' ), '', get_comment_author() ); ?>
		</figure>

		<div class="comment-text">

			<?php if ( $rating && get_option( 'woocommerce_enable_review_rating' ) == 'yes' ) : ?>

				<div itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating">
					<strong itemprop="ratingValue" style="display: none"><?php echo $rating; ?></strong>
				</div>


			<?php endif; ?>

			<?php if ( $comment->comment_approved == '0' ) : ?>

				<div class="user"><p class="meta"><em><?php _e( 'Your comment is awaiting approval', 'trendy' ); ?></em></p></div>

			<?php else : ?>

				<div class="user">
					<a itemprop="author"><?php comment_author(); ?></a>
					<?php
					if(isset($rating) && $rating != 0) {
						echo '(' . __('rated', 'trendy') . ' <div class="comment_rating">';
						$rating = (int)$rating; 
						$rating2 = 5 - $rating;
						for($i=1; $i<=$rating; $i++) {
							echo '<i class="fa fa-star"></i>';
						}
						for($i=1; $i <= $rating2; $i++) {
							echo '<i class="fa fa-star-o"></i>';
						}
						echo '</div>)';
					}

						if ( get_option( 'woocommerce_review_rating_verification_label' ) === 'yes' )
							if ( wc_customer_bought_product( $comment->comment_author_email, $comment->user_id, $comment->comment_post_ID ) )
								echo '<em class="verified">(' . __( 'verified owner', 'trendy' ) . ')</em> ';
						echo ' ' . __('says:', 'trendy');
					?>
				</div>

			<?php endif; ?>

			<div itemprop="description" class="content"><?php echo get_comment_text(); ?></div>

			<div class="date">
				<time itemprop="datePublished" datetime="<?php echo get_comment_date( 'c' ); ?>">
					<?php echo get_comment_date( __( get_option( 'date_format' ), 'trendy' ) ); ?>
				</time>
			</div>

		</div>
	</div>
