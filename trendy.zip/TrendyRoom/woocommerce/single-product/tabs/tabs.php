<?php
/**
 * Single Product tabs
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Filter tabs and allow third parties to add their own
 *
 * Each tab is an array containing title, callback and priority.
 * @see woocommerce_default_product_tabs()
 */
$tabs = apply_filters( 'woocommerce_product_tabs', array() );

if ( ! empty( $tabs ) ) : ?>

	<div class="row">
		<div class="col-sm-9">
			<div class="tab-content">
				<?php $i = 1; foreach ( $tabs as $key => $tab ) : ?>
					<div class="tab-pane <?php if($i == 1) echo 'active';?> text-editor" id="tab-<?php echo $key ?>">
						<?php call_user_func( $tab['callback'], $key, $tab ) ?>
					</div>
				<?php $i++; endforeach; $i = 1; ?>
			</div>
		</div>

		<div class="col-sm-3 hidden-xs">
			<ul class="nav nav-tabs">
				<?php foreach ( $tabs as $key => $tab ) : ?>
					<li <?php if($i == 1) echo 'class="active"';?>>
						<a href="#tab-<?php echo $key ?>" data-toggle="tab"><?php echo apply_filters( 'woocommerce_product_' . $key . '_tab_title', $tab['title'], $key ) ?></a>
					</li>
				<?php $i++; endforeach; ?>
		    </ul>
		</div>
	</div>

<?php endif; ?>