<?php
/**
 * The template for displaying product content within loops.
 *
 * Override this template by copying it to yourtheme/woocommerce/content-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $product, $woocommerce_loop;

// Ensure visibility
if ( ! $product || ! $product->is_visible() )
	return;

// Extra post classes
$classes = 'col-sm-3 col-xs-6';
?>
<div <?php post_class( $classes ); ?>>
	<div class="grid-product">

		<?php 
		$thumb = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
		$resized = teo_resize($thumb, 339, 339, true); 
		if($thumb != '') { ?>
			<figure>
				<a href="<?php the_permalink();?>">
					<img src="<?php echo $resized;?>" alt="<?php the_title();?>" />
				</a>
			</figure>
		<?php } ?>
		<div class="overlay">
			<?php 
			$product = new WC_Product( get_the_ID() );
			$price = $product->price;
			?>
			<meta itemprop="price" content="<?php echo $product->get_price(); ?>" />
			<meta itemprop="priceCurrency" content="<?php echo get_woocommerce_currency(); ?>" />
			<link itemprop="availability" href="http://schema.org/<?php echo $product->is_in_stock() ? 'InStock' : 'OutOfStock'; ?>" />
            <div class="price"><?php echo $product->get_price_html(); ?></div>
            <div class="background"></div>
        </div>

        <a class="view-product" href="<?php the_permalink();?>">
            <div class="text"><?php _e('View product', 'trendy');?></div>
            <div class="background"></div>
        </a>

	</div>
</div>