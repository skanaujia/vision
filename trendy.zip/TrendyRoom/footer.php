<?php global $teo_data; ?>
<footer class="main-footer">
        <div class="container">
            <div class="row">
                <?php dynamic_sidebar("Footer sidebar");?>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="final-line">
                        <div class="row">
                            <div class="col-sm-6 col-xs-6">
                                <p>&copy; <?php echo date("Y") . ' ' . get_bloginfo('name') . '. '; _e('All Rights Reserved.', 'trendy'); ?></p>
                                <ul class="social-icons">
                                    <?php if(isset($teo_data['twitter_url']) && $teo_data['twitter_url'] != '') { ?>
                                        <li><a href="<?php echo esc_url($teo_data['twitter_url']);?>"><i class="fa fa-twitter"></i></a></li>
                                    <?php } ?>

                                    <?php if(isset($teo_data['instagram_url']) && $teo_data['instagram_url'] != '') { ?>
                                        <li><a href="<?php echo esc_url($teo_data['twitter_url']);?>"><i class="fa fa-instagram"></i></a></li>
                                    <?php } ?>

                                    <?php if(isset($teo_data['facebook_url']) && $teo_data['facebook_url'] != '') { ?>
                                        <li><a href="<?php echo esc_url($teo_data['facebook_url']);?>"><i class="fa fa-facebook"></i></a></li>
                                    <?php } ?>

                                    <?php if(isset($teo_data['flickr_url']) && $teo_data['flickr_url'] != '') { ?>
                                        <li><a href="<?php echo esc_url($teo_data['flickr_url']);?>"><i class="fa fa-flickr"></i></a></li>
                                    <?php } ?>
                                    
                                    <?php if(isset($teo_data['dribbble_url']) && $teo_data['dribbble_url'] != '') { ?>
                                        <li><a href="<?php echo esc_url($teo_data['dribbble_url']);?>"><i class="fa fa-dribbble"></i></a></li>
                                    <?php } ?>

                                    <?php if(isset($teo_data['googleplus_url']) && $teo_data['googleplus_url'] != '') { ?>
                                        <li><a href="<?php echo esc_url($teo_data['googleplus_url']);?>"><i class="fa fa-google-plus"></i></a></li>
                                    <?php } ?>

                                    <li><a href="<?php bloginfo('rss_url'); ?>"><i class="fa fa-rss"></i></a></li>

                                    <?php if(isset($teo_data['pinterest_url']) && $teo_data['pinterest_url'] != '') { ?>
                                        <li><a href="<?php echo esc_url($teo_data['pinterest_url']);?>"><i class="fa fa-pinterest"></i></a></li>
                                    <?php } ?>
                                </ul>
                            </div>
                            <div class="col-sm-6 text-right col-xs-6">
                                <p><?php _e('Developed by', 'trendy');?> <a target="_blank" href="http://teothemes.com" title="WordPress Themes">TeoThemes</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="login-form">
                        <h3><?php _e("Let's get started,", 'trendy');?></h3>
                        <form role="form" method="post" action="<?php echo site_url('wp-login.php', 'login_post') ?>">
                            <?php 
                            global $wp;
                            $current_url = add_query_arg( $wp->query_string, '', home_url( $wp->request ) );
                            ?>
                            <div class="form-group">
                                <label for="login-username"><?php _e('Username', 'trendy');?></label>
                                <input type="text" class="form-control" id="login-username" name="log">
                            </div>
                            <div class="form-group">
                                <label for="login-password"><?php _e('Password', 'trendy');?></label>
                                <input type="password" class="form-control" id="login-password" name="pwd">
                            </div>
                            <div class="form-group">
                                <a class="forgotten" href="<?php echo wp_lostpassword_url($current_url);?>"><?php _e('Forgot password?', 'trendy');?></a>
                                <button type="submit" class="btn btn-default" name="wp-submit"><?php _e('Login', 'trendy');?></button>
                            </div>
                            <input type="hidden" name="redirect_to" value="<?php echo $current_url;?>" />
                        </form>
                    </div>
                    <hr/>
                    <div class="register-form">
                        <h3><?php _e('New customer?', 'trendy');?></h3>
                        <form role="form" method="post" action="<?php echo site_url('wp-login.php?action=register', 'login_post') ?>">
                            <div class="form-group">
                                <label for="register-username"><?php _e('Username', 'trendy');?></label>
                                <input type="text" class="form-control" id="register-username" name="user_login">
                            </div>
                            <div class="form-group">
                                <label for="register-email"><?php _e('Email', 'trendy');?></label>
                                <input type="email" class="form-control" id="register-email" name="user_email">
                            </div>

                            <input type="hidden" name="redirect_to" value="<?php echo home_url('/');?>"/>

                            <div class="form-group">
                                <button name="submit" type="submit" class="btn btn-default"><?php _e('Register', 'trendy');?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php wp_footer();?>
</body>
</html>
