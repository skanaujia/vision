<?php 
get_header();
the_post();
$format = get_post_format();
$video = get_post_meta($post->ID, '_single_video', true);
?>
<section class="main-container">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">
                <div class="post">
                    <h2><?php the_title();?></h2>
                    <div class="post-info">
                        <ul>
                            <li>
                                <?php the_date(); 
                                echo ' ';
                                _e('by', 'trendy');
                                echo ' ';
                                the_author_posts_link(); 
                                $categories = get_the_category();
                                if(is_array($categories) && count($categories > 0) ) { 
                                    echo ' ';
                                    _e('in', 'trendy');
                                    echo ' ';
                                    for($i=0; $i<count($categories); $i++) {
                                        echo '<a href="' . get_category_link($categories[$i]->term_id)  . '">' . $categories[$i]->name . '</a>';
                                        if($i != count($categories) -1)
                                            echo ',';
                                    }
                                }
                            ?>
                            </li>
                        </ul>
                    </div>
                    <?php 
                    if($format == 'video' && $video != '') { 
                        if(isset($GLOBALS['wp_embed'])) {
                            ?>
                            <figure>
                                <?php
                                $embed = $GLOBALS['wp_embed']->autoembed($video);
                                $embed = str_replace("feature=oembed", "feature=oembed&amp;wmode=transparent", $embed);
                                echo $embed;
                                ?>
                            </figure>
                        <?php 
                        }
                    } 
                    elseif(has_post_thumbnail() ) { 
                        $thumb = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                        $resized = teo_resize($thumb, 750, 355, false);
                        ?>
                        <figure>
                            <img src="<?php echo $resized;?>" alt="<?php the_title();?>" />
                        </figure>
                    <?php } ?>
                    <div class="post-content text-editor">
                        <?php 
                        the_content();
                        wp_link_pages(array('before' => '<div class="single-navigation"><strong>'.esc_html__('Pages','trendy').':</strong> ', 'after' => '</div>', 'next_or_number' => 'number'));
                        $posttags = get_the_tags();
                        if($posttags) { ?>
                            <hr />
                            <div class="tags">
                                <?php _e('Tags: ', 'trendy');
                                $i = 1;
                                foreach($posttags as $tag)  {
                                    if($i != count($posttags) ) {
                                        echo '<a href="' . get_tag_link($tag->term_id) . '">' . $tag->name . '</a>, ';
                                    }
                                    else {
                                        echo '<a href="' . get_tag_link($tag->term_id) . '">' . $tag->name . '</a>';
                                    }
                                    $i++;
                                }
                                ?>
                            </div>
                        <?php } ?>

                        <hr />

                        <div class="single-navigation">
                            <?php previous_post_link("<div class='prev'>&laquo; %link</div>"); ?>
                            <?php next_post_link("<div class='next'>%link &raquo;</div>"); ?> 
                        </div>

                        <hr />

                        <!-- AddThis Button BEGIN -->
                        <div class="addthis_toolbox addthis_default_style addthis_32x32_style">
                        <a class="addthis_button_preferred_1"></a>
                        <a class="addthis_button_preferred_2"></a>
                        <a class="addthis_button_preferred_3"></a>
                        <a class="addthis_button_preferred_4"></a>
                        <a class="addthis_button_compact"></a>
                        <a class="addthis_counter addthis_bubble_style"></a>
                        </div>
                        <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=xa-5349b56b1751e8a6"></script>
                        <!-- AddThis Button END -->
                    </div>
                </div>
                
                <?php comments_template('', true); ?>
            </div>
        </div>
    </div>
</section>
<?php get_footer();?>