<?php
/**
 * Include and setup custom metaboxes and fields.
 *
 * @category TrendyRoom
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress
 */

add_filter( 'cmb_meta_boxes', 'cmb_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
function cmb_sample_metaboxes( array $meta_boxes ) {

	$prefix = '_single_';

	$meta_boxes[] = array(
		'id'         => 'videopost_metabox',
		'title'      => 'Custom info for video post',
		'pages'      => array( 'post', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(
			array( // Text Input
			    'name' => 'External video URL', // <label>
			    'desc'  => 'Use this field if you want to use a video from Vimeo or Youtube!', // description
			    'id'    => $prefix . 'video', // field id and name
			    'type'  => 'oembed', // type of field,
			    ),
		)
	);

	$prefix = '_contact_';

	$meta_boxes[] = array(
		'id'         => 'contact_metabox',
		'title'      => 'Custom info for contact page template',
		'show_on'    => array( 'key' => 'page-template', 'value' => 'page-template-contact.php'),
		'pages'      => array( 'page', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(
			array( // Text Input
			    'name' => 'Google Maps embed code', // <label>
			    'desc'  => 'You can get the iframe code from maps.google.com (more details http://i.imgur.com/HDtSkS2.png )!', // description
			    'id'    => $prefix . 'map', // field id and name
			    'type'  => 'textarea', // type of field,
			    'sanitization_cb' => ''
			    ),
			array( // Text Input
			    'name' => 'Title on the map', // <label>
			    'desc'  => 'You can set a title that will appear on the map block!', // description
			    'id'    => $prefix . 'title', // field id and name
			    'type'  => 'text', // type of field,
			    'sanitization_cb' => ''
			    ),
			array( // Text Input
			    'name' => 'Address text on the map', // <label>
			    'desc'  => 'The address will appear on the map, you can use html tags!', // description
			    'id'    => $prefix . 'address', // field id and name
			    'type'  => 'textarea', // type of field,
			    'sanitization_cb' => ''
			    ),
			array( // Text Input
			    'name' => 'Phone, text on the map', // <label>
			    'desc'  => 'The phone will appear on the map, below the address, you can use html tags!', // description
			    'id'    => $prefix . 'phone', // field id and name
			    'type'  => 'text', // type of field,
			    'sanitization_cb' => ''
			    ),
		)
	);

	$prefix = '_ourstory_';

	$meta_boxes[] = array(
		'id'         => 'story_metabox',
		'title'      => 'Custom info for the Our Story page template',
		'show_on'    => array( 'key' => 'page-template', 'value' => 'page-template-story.php'),
		'pages'      => array( 'page', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(
			array( // Text Input
			    'name' => 'Top Background Image(if applicable)', // <label>
			    'desc'  => 'You can have a background image with text over it, in the header, if you want to use it.', // description
			    'id'    => $prefix . 'bgimage', // field id and name
			    'type'  => 'file', // type of field,
			    ),
			array( // Text Input
			    'name' => 'Quote Text over the background image', // <label>
			    'desc'  => 'If you set a background image and want to show a quote or some text, add it here. REQUIRES the above background image to be set!', // description
			    'id'    => $prefix . 'quotetext', // field id and name
			    'type'  => 'textarea', // type of field,
			    'sanitization_cb' => ''
			    ),
			array( // Text Input
			    'name' => 'Quote author over the background image', // <label>
			    'desc'  => 'The quote author will show up below the quote text, on the background image. REQUIRES the above background image to be set!', // description
			    'id'    => $prefix . 'quoteauthor', // field id and name
			    'type'  => 'text', // type of field,
			    'sanitization_cb' => ''
			    ),
			array(
			    'id'          => $prefix . 'tabs',
			    'type'        => 'group',
			    'description' => __( 'Our Story details tabs', 'cmb' ),
			    'options'     => array(
			        'add_button'    => __( 'Add Another Entry', 'cmb' ),
			        'remove_button' => __( 'Remove Entry', 'cmb' ),
			        'sortable'      => true, // beta
			    ),
			    // Fields array works the same, except id's only need to be unique for this group. Prefix is not needed.
			    'fields'      => array(
			        array(
			            'name' => 'Tab Title',
			            'id'   => 'tab_title',
			            'type' => 'text',
			            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
			        ),
			        array(
			            'name' => 'Tab Text',
			            'description' => 'The tab text that will show up',
			            'id'   => 'tab_text',
			            'type' => 'wysiwyg',
			        ),
			    ),
			),

		)
	);

	$prefix = '_shop_';

	$categories = get_terms( 'product_cat' );
	$cats = array();
	if($categories && is_array($categories) ) {
		foreach($categories as $cat) {
			$cats[$cat->term_id] = $cat->name;
		}
	}

	$meta_boxes[] = array(
		'id'         => 'shop_metabox',
		'title'      => 'Custom info for contact page template',
		'show_on'    => array( 'key' => 'page-template', 'value' => 'page-template-shop.php'),
		'pages'      => array( 'page', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(
			array( // Text Input
			    'name' => 'Categories to include', // <label>
			    'desc'  => 'You can select here which categories should be included on the shop page!', // description
			    'id'    => $prefix . 'categories', // field id and name
			    'type'  => 'multicheck', // type of field,
			    'options' => $cats
			    ),
		)
	);

	$prefix = '_homepage_';

	$categories = get_terms( 'product_cat' );
	$cats = array();
	if($categories && is_array($categories) ) {
		foreach($categories as $cat) {
			$cats[$cat->term_id] = $cat->name;
		}
	}

	$meta_boxes[] = array(
		'id'         => 'homepage_metabox',
		'title'      => 'Custom info for the homepage page template',
		'show_on'    => array( 'key' => 'page-template', 'value' => 'page-template-home.php'),
		'pages'      => array( 'page', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(
			array(
			    'name'    => 'Enable featured slider',
			    'desc'	  => 'The featured slider shows below the navigation menu',
			    'id'      => $prefix . 'enable_slider',
			    'type'    => 'radio',
			    'options' => array(
			        '1'   => __( 'Yes', 'cmb' ),
			        '2'   => __( 'No', 'cmb' ),
			    ),
			    'std'     => '1'
			),
			array(
			    'name'    => 'Categories to include in the featured slider',
			    'desc'	  => 'Here you can set the categories that are going to be included in the featured slider products',
			    'id'      => $prefix . 'slider_categories', // field id and name
			    'type'    => 'multicheck', // type of field,
			    'options' => $cats
			),
			array(
			    'name'    => 'Number of products shown in the featured slider',
			    'id'      => $prefix . 'slider_number',
			    'type'    => 'text',
			    'std' 	  => '5'
			),
			array(
			    'name'    => 'Enable slogan',
			    'desc'	  => 'The slogan shows up below the featured slider and you can set the text in the below option',
			    'id'      => $prefix . 'enable_slogan',
			    'type'    => 'radio',
			    'options' => array(
			        '1'   => __( 'Yes', 'cmb' ),
			        '2'   => __( 'No', 'cmb' ),
			    ),
			    'std'     => '1'
			),
			array(
			    'name'    => 'Slogan Text',
			    'desc'	  => 'Here you can set the slogan that shows up below the featured slider(you can use HTML tags)',
			    'id'      => $prefix . 'slogan_text',
			    'type'    => 'textarea_small',
			    'std'     => ''
			),
			array( // Text Input
			    'name'    => 'Categories to include in the filterable products showcase', // <label>
			    'desc'    => 'You can select here which categories should be included on the shop page!', // description
			    'id'      => $prefix . 'categories', // field id and name
			    'type'    => 'multicheck', // type of field,
			    'options' => $cats
			),
			array(
			    'name'    => 'Number of products shown on each category in the filterable products showcase',
			    'desc'    => 'The section shows 4 products per line so a number that divides by 4 is recommended.',
			    'id'      => $prefix . 'filterable_number',
			    'type'    => 'text',
			    'std' 	  => '8'
			),
		)
	);

	return $meta_boxes;
}
?>