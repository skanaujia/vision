<?php
add_action('init', 'teo_post_types');
function teo_post_types() {
  $labels = array(
    'name' => 'Testimonials',
    'singular_name' => 'Testimonial',
    'add_new' => 'Add',
    'add_new_item' => 'Add a new testimonial',
    'edit_item' => 'Edit testimonial',
    'new_item' => 'New testimonial',
    'all_items' => 'All testimonials',
    'view_item' => 'View testimonial details',
    'search_items' => 'Search testimonial',
    'not_found' =>  'No testimonial found',
    'not_found_in_trash' => 'No testimonial in the trash.' , 
    'parent_item_colon' => '',
    'menu_name' => 'Testimonials'

  );
  $args = array(
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true, 
    'show_in_menu' => true, 
    'query_var' => true,
    'rewrite' => true,
    'capability_type' => 'post',
    'has_archive' => false, 
    'hierarchical' => false,
    'menu_position' => null,
    'supports' => array('title', 'editor')
  ); 
  
  register_post_type('testimonial',$args);
}
?>