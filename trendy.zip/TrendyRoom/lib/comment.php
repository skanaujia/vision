<?php
/* custom comment callback function */
function teo_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment;
   ?>

   <li <?php comment_class('comment'); ?> id="comment-<?php comment_ID() ?>">
        <div id="comment-<?php comment_ID(); ?>">
            <figure>
                <?php echo get_avatar($comment, 80); ?>
            </figure>
            <div class="user">     
                <a><?php echo get_comment_author();?></a> <?php echo _e('says', 'trendy'); ?>
            </div>
            
            <div class="content">
                <?php echo get_comment_text(); ?>
                <div class="manage-comment">
                    <?php
                    $reply_link = get_comment_reply_link( array_merge( $args, array('reply_text' => '<i class="fa fa-reply"></i>','depth' => $depth, 'max_depth' => $args['max_depth'])) );
                    if($reply_link) { 
                        echo $reply_link;
                    } 
                    echo '&nbsp;&nbsp;';
                    edit_comment_link( '<i class="fa fa-edit"></i>', ' ' );
                    ?>
                </div>
                <?php if ($comment->comment_approved == '0') : ?>
                    <p>
                        <em class="moderation"><?php esc_html_e('Your comment is awaiting moderation.','Cleanse') ?></em>
                    </p>
                <?php endif; ?>
            </div>

            <div class="date">
                <?php echo (get_comment_date('F jS, Y'));?>
            </div>
        </div>
<?php }