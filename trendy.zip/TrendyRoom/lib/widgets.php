<?php
// Testimonials Widget
class TeoTestimonialsWidget extends WP_Widget
{
    function TeoTestimonialsWidget(){
    $widget_ops = array('description' => 'Shows a slider of user testimonials.');
    $control_ops = array('width' => 200, 'height' => 300);
    parent::__construct(false,$name='[Trendy] Testimonials',$widget_ops,$control_ops);
    }

  /* Displays the Widget in the front-end */
    function widget($args, $instance){
    extract($args);

    $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title']);
    $number_posts = $instance['number_posts'];

    echo $before_widget; 

    echo '<div class="testimonial">';

    if ( $title != '' )
        echo $before_title . $title . $after_title;

    echo '<div class="testimonials-slider">
        <ul class="slides">';
    $args = array();
    $args['post_type'] = 'testimonial';
    $args['orderby'] = 'rand';
    $args['posts_per_page'] = $number_posts != 0 ? $number_posts : 5;
    $query = new WP_Query($args);
    while($query->have_posts() ) : $query->the_post(); global $post; ?>
        <li>
            <div class="icon-wrap">
                <i class="fa fa-quote-left"></i>
            </div>
            <br>
            <?php the_content('');?>
            <div class="separator"></div>
            <br>
            <div class="author">
            <a><?php the_title();?></a>
            </div>
        </li>
    <?php 
    endwhile; wp_reset_postdata(); 
    echo '</ul>
    </div>
    </div>';

    echo $after_widget;
  }

  /*Saves the settings. */
    function update($new_instance, $old_instance){
    $instance =  array();
    $instance['title'] = esc_attr($new_instance['title']);
    $instance['number_posts'] = (int)$new_instance['number_posts'];

    return $instance;
  }

  /*Creates the form for the widget in the back-end. */
    function form($instance){
    //Defaults
    $instance = wp_parse_args( (array) $instance, array('number_posts'=> 5, 'title' => '' ) );

    $title = esc_attr($instance['title']);
    $number_posts = (int) $instance['number_posts'];
    
    echo '<p><label for="' . $this->get_field_id('title') . '">' . 'Title: ' . '</label><input id="' . $this->get_field_id('title') . '" name="' . $this->get_field_name('title') . '" value="'. esc_textarea($title)  . '" /></p>';
    echo '<p><label for="' . $this->get_field_id('number_posts') . '">' . 'Number of testimonials: ' . '</label><input id="' . $this->get_field_id('number_posts') . '" name="' . $this->get_field_name('number_posts') . '" value="'. esc_textarea($number_posts)  . '" /></p>';
  }

}// end Testimonials class

// Latest Posts Widget
class TeoLatestPostsWidget extends WP_Widget
{
    function TeoLatestPostsWidget(){
    $widget_ops = array('description' => 'Shows the latest blog posts.');
    $control_ops = array('width' => 200, 'height' => 300);
    parent::__construct(false,$name='[Trendy] Latest posts',$widget_ops,$control_ops);
    }

  /* Displays the Widget in the front-end */
    function widget($args, $instance){
    extract($args);

    $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title']);
    $number_posts = $instance['number_posts'];
    $categories = $instance['categories'];

    echo $before_widget; 

    echo '<div class="anouncements">';

    if ( $title != '' )
        echo $before_title . $title . $after_title;

    echo '<ul>';
    $args = array();
    if(!empty($categories) )
        $args['category__in'] = $categories;
    $args['posts_per_page'] = $number_posts != 0 ? $number_posts : 3;
    $query = new WP_Query($args);
    while($query->have_posts() ) : $query->the_post(); global $post; ?>
        <li>
            <div class="date"><?php the_time('F dS, Y');?></div>
            <p><a href="<?php the_permalink();?>"><?php the_title();?></a></p>
        </li>
    <?php 
    endwhile; wp_reset_postdata(); 
    echo '</ul>
    </div>';

    echo $after_widget;
  }

  /*Saves the settings. */
    function update($new_instance, $old_instance){
    $instance =  array();
    $instance['title'] = esc_attr($new_instance['title']);
    $instance['number_posts'] = (int)$new_instance['number_posts'];
    $instance['categories'] = $new_instance['categories'];

    return $instance;
  }

  /*Creates the form for the widget in the back-end. */
    function form($instance){
    //Defaults
    $instance = wp_parse_args( (array) $instance, array('number_posts'=> 3, 'title' => '', 'categories' => array() ) );

    $title = esc_attr($instance['title']);
    $number_posts = (int) $instance['number_posts'];
    $categories = (array) $instance['categories'];
    
    echo '<p><label for="' . $this->get_field_id('title') . '">' . 'Title: ' . '</label><br /><input id="' . $this->get_field_id('title') . '" name="' . $this->get_field_name('title') . '" value="'. esc_textarea($title)  . '" /></p>';
    echo '<p><label for="' . $this->get_field_id('number_posts') . '">' . 'Number of blog posts: ' . '</label><br /><input id="' . $this->get_field_id('number_posts') . '" name="' . $this->get_field_name('number_posts') . '" value="'. esc_textarea($number_posts)  . '" /></p>';
    $cats = get_categories('hide_empty=0');
    ?>
    <p>
        <label>Categories to include: </label> <br />
        <?php foreach( $cats as $category ) { ?>
            <label>
                <input type="checkbox" name="<?php echo $this->get_field_name('categories'); ?>[]" value="<?php echo $category->cat_ID; ?>"  <?php if(in_array( $category->cat_ID, $categories ) ) echo 'checked="checked" '; ?> /> 
                <?php echo $category->cat_name; ?>
            </label> <br />
        <?php } ?>
    </p> 
    <?php
  }

}// end TeoLatestPostsWidget class

// TeoSitemapWidget
class TeoSitemapWidget extends WP_Widget
{
    function TeoSitemapWidget(){
    $widget_ops = array('description' => 'Shows the latest pages and products.');
    $control_ops = array('width' => 200, 'height' => 300);
    parent::__construct(false,$name='[Trendy] Sitemap',$widget_ops,$control_ops);
    }

  /* Displays the Widget in the front-end */
    function widget($args, $instance){
    extract($args);

    $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title']);
    $number_posts = $instance['number_posts'];

    echo $before_widget; 

    if ( $title != '' )
        echo $before_title . $title . $after_title;

    echo '<div class="sitemap">
        <ul>';
    //showing pages on the first column
    $args = array();
    $args['post_type'] = 'page';
    $args['posts_per_page'] = $number_posts != 0 ? $number_posts : 5;
    $query = new WP_Query($args);
    while($query->have_posts() ) : $query->the_post(); global $post; ?>
        <li><a href="<?php the_permalink();?>"><?php the_title();?></a></li>
    <?php 
    endwhile; wp_reset_postdata(); 
    echo '
    </ul>
    <ul>';
    //products on the second column
    $args = array();
    $args['post_type'] = 'product';
    $args['posts_per_page'] = $number_posts != 0 ? $number_posts : 5;
    $query = new WP_Query($args);
    while($query->have_posts() ) : $query->the_post(); global $post; ?>
        <li><a href="<?php the_permalink();?>"><?php the_title();?></a></li>
    <?php 
    endwhile; wp_reset_postdata(); 
    echo '</ul>
    </div>';

    echo $after_widget;
  }

  /*Saves the settings. */
    function update($new_instance, $old_instance){
    $instance =  array();
    $instance['title'] = esc_attr($new_instance['title']);
    $instance['number_posts'] = (int)$new_instance['number_posts'];

    return $instance;
  }

  /*Creates the form for the widget in the back-end. */
    function form($instance){
    //Defaults
    $instance = wp_parse_args( (array) $instance, array('number_posts'=> 5, 'title' => '' ) );

    $title = esc_attr($instance['title']);
    $number_posts = (int) $instance['number_posts'];
    
    echo '<p><label for="' . $this->get_field_id('title') . '">' . 'Title: ' . '</label><br /><input id="' . $this->get_field_id('title') . '" name="' . $this->get_field_name('title') . '" value="'. esc_textarea($title)  . '" /></p>';
    echo '<p><label for="' . $this->get_field_id('number_posts') . '">' . 'Number of items on each row: ' . '</label><br /><input id="' . $this->get_field_id('number_posts') . '" name="' . $this->get_field_name('number_posts') . '" value="'. esc_textarea($number_posts)  . '" /></p>';
  }

}// end TeoSitemapWidget class


// Text Box Widget
class TeoTextBoxWidget extends WP_Widget
{
    function TeoTextBoxWidget(){
    $widget_ops = array('description' => 'A box with text and a background.');
    $control_ops = array('width' => 200, 'height' => 300);
    parent::__construct(false,$name='[Trendy] Box With Text',$widget_ops,$control_ops);
    }

  /* Displays the Widget in the front-end */
    function widget($args, $instance){
    extract($args);

    $text = $instance['text'];
    $img = $instance['image_uri'];

    echo $before_widget; 

    $inline = '';
    if($img != '') {
        $inline = 'style="background-image: url(\'' . $img . '\')"';
    }

    echo '<div class="widget big-text" ' . $inline . '>' . $text . '</div>';

    echo $after_widget;
  }

  /*Saves the settings. */
    function update($new_instance, $old_instance){
    $instance =  array();
    $instance['text'] = $new_instance['text'];
    $instance['image_uri'] = esc_url($new_instance['image_uri']);

    return $instance;
  }

  /*Creates the form for the widget in the back-end. */
    function form($instance){
    //Defaults
    $instance = wp_parse_args( (array) $instance, array('text' => '', 'image_uri' => '') );

    $text = $instance['text'];
    $img    = $instance['image_uri'];
    
    ?>
    <p>
        <label for="<?php echo $this->get_field_id('image_uri'); ?>">Image URL:</label><br />
        <input type="text" class="img widefat" name="<?php echo $this->get_field_name('image_uri'); ?>" id="<?php echo $this->get_field_id('image_uri'); ?>" value="<?php echo $img; ?>" />
    </p>
    <p>
        <input type="button" class="button select-img" data-update-id="<?php echo $this->get_field_id('image_uri'); ?>" value="Select Image" />
    </p>
    <p>
        <label for="<?php echo $this->get_field_id('text');?>">Text:</label><br />
        <textarea class="widefat" id="<?php echo $this->get_field_id('text');?>" name="<?php echo $this->get_field_name('text');?>"><?php echo esc_textarea($text);?></textarea>
    </p>
  <?php }

}// end TeoTextBoxWidget class


function TeoWidgets() {
    register_widget('TeoTestimonialsWidget');
    register_widget('TeoLatestPostsWidget');
    register_widget('TeoTextBoxWidget');
    register_widget('TeoSitemapWidget');
  
}

add_action('widgets_init', 'TeoWidgets');
