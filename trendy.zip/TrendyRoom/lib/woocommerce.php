<?php

add_theme_support( 'woocommerce' );

// Disable WooCommerce styles
add_filter( 'woocommerce_enqueue_styles', '__return_false' );

add_action( 'wp_enqueue_scripts', 'teo_manage_woocommerce_styles', 99 );
function teo_manage_woocommerce_styles() {
	wp_dequeue_script( 'wc-chosen' );
}

// Remove WC sidebar
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10);

// Adjust markup on all WooCommerce pages
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

add_action('woocommerce_before_main_content', 'teo_before_content', 10);
add_action('woocommerce_after_main_content', 'teo_after_content', 20);

//removing the breadcrumbs since we don't use them
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0);

function teo_remove_reviews_tab($tabs) {
	unset($tabs['reviews']);
	return $tabs;
}

// remove reviews from regular tabs
add_filter( 'woocommerce_product_tabs', 'teo_remove_reviews_tab', 98);

// Fix the layout etc
function teo_before_content() {
	?>
	<!-- #content Starts -->
    <section class="main-container">
    	<div class="container">
    		<div class="row">
    <?php
}
function teo_after_content() {
	?>
			</div>
		</div>
	</section>
	<?php 
}

?>