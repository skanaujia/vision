<div class="paginate">
	<?php
	if(function_exists('wp_pagenavi')) 
		wp_pagenavi(); 
	else { ?>
		<div class="single-navigation">
			<div class="prev"><?php next_posts_link(esc_attr__('&laquo; Older posts', 'Aruna')); ?></div>
			<div class="next"><?php previous_posts_link(esc_attr__('Newer posts &raquo;', 'Aruna')); ?></div>
		</div>
	<?php } ?>
</div>