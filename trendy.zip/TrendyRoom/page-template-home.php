<?php 
/* 
Template name: Home page template 
*/

get_header();
the_post(); 
$enable_slider = get_post_meta($post->ID, '_homepage_enable_slider', true);
$slider_categories = get_post_meta($post->ID, '_homepage_slider_categories', true);
$slider_number = (int)get_post_meta($post->ID, '_homepage_slider_number', true);
$enable_slogan = get_post_meta($post->ID, '_homepage_enable_slogan', true);
$slogan_text = get_post_meta($post->ID, '_homepage_slogan_text', true);
$categories = get_post_meta($post->ID, '_homepage_categories', true);
$filterable_number = (int)get_post_meta($post->ID, '_homepage_filterable_number', true);
if($enable_slider == 1 && $slider_number != 0 && teo_is_woo_active() ) { 
    $args = array();
    $args['post_type'] = 'product';
    if(is_array($slider_categories) && count($slider_categories) > 0) {
        $args['tax_query'] = array(
            array( 
                'taxonomy' => 'product_cat',
                'terms' => $slider_categories
            )
        );
    }
    $args['posts_per_page'] = $slider_number;
    $query = new WP_Query($args);
    if($query->have_posts() ) : ?>
        <div class="homepage-slider-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="homepage-slider">
                            <ul class="slides">
                                <?php while($query->have_posts() ) : $query->the_post(); global $post;
                                    $thumb = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                                    $high = teo_resize($thumb, 1140, 550);
                                    if($high != '') { ?>
                                        <li style="background-image: url('<?php echo $high;?>');">
                                            <a href="<?php the_permalink();?>"><div class="overlay"></div></a>
                                        </li>
                                    <?php } ?> 
                                <?php endwhile; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; wp_reset_postdata();
} ?>

<?php if($enable_slogan == 1 && $slogan_text != '') { ?>
    <section class="homepage-quote">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2">
                    <div class="text"><?php echo $slogan_text;?></div>
                </div>
            </div>
        </div>
    </section>
<?php } ?>

<?php
if(teo_is_woo_active() ) { 
    //filterable products showcase
    $args = array();
    if(is_array($categories) && count($categories) > 0) {
        $args['include'] = $categories;
    }
    else {
        $args['number'] = 6;
    }
    $product_cats = get_terms('product_cat', $args);
    ?>
    <section class="hp-tabs">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ul class="nav nav-tabs">
                        <?php
                        $i = 1;
                        foreach($product_cats as $cat) { 
                            $thumbnail_id = get_woocommerce_term_meta( $cat->term_id, 'thumbnail_id', true );
                            $image = wp_get_attachment_url( $thumbnail_id );
                            $thumb = teo_resize($image, 89, 80);
                            if($thumb != '') { ?>
                                <li <?php if($i==1) echo 'class="active"';?>>
                                    <a href="#tab<?php echo $i;?>" data-toggle="tab"><span class="inner"><img src="<?php echo $thumb;?>" alt="<?php echo $cat->name;?>" /></span></a>
                                </li>
                        <?php } $i++; 
                        } ?>
                    </ul>
                    <div class="tab-content">
                        <?php
                        $i = 1;
                        foreach($product_cats as $cat) { 
                            $args = array();
                            $args['post_type'] = 'product';
                            $args['posts_per_page'] = $filterable_number != 0 ? $filterable_number : 8;
                            if(is_array($categories) && count($categories) > 0) {
                                $args['tax_query'] = array(
                                    array( 
                                        'taxonomy' => 'product_cat',
                                        'terms' => (array)$cat->term_id
                                    )
                                );
                            }
                            $query = new WP_Query($args);?>
                            <div class="tab-pane fade <?php if($i==1) echo 'in active';?>" id="tab<?php echo $i;?>">
                                <div class="grid-products-wrapper">
                                    <div class="row">
                                        <?php 
                                        while($query->have_posts() ) : $query->the_post(); global $post; 
                                            wc_get_template_part( 'content', 'product' ); 
                                        endwhile; wp_reset_postdata();
                                        ?>
                                    </div>
                                </div>
                            </div>
                        <?php $i++; } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php } ?>

<section class="hp-section">
    <div class="container">
    <?php the_content('');?>
    </div>
</section>

<?php get_footer();?>