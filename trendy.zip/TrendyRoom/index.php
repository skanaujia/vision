<?php get_header();?>
<section class="filters-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <ul class="categories">
                    <li><?php _e('Categories:', 'trendy');?></li>
                    <li><a class="active" href="#" data-filter="*"><?php _e('All', 'trendy');?></a></li>
                    <?php 
                    $categories = get_categories();
                    foreach($categories as $cat) { ?>
                        <li><a href="#" data-filter=".filter-<?php echo $cat->category_nicename;?>"><?php echo $cat->name;?></a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </div>
</section>
<section class="products-wrapper">
    <div class="container">
        <div class="row">
            <?php 
            if(have_posts() ) : ?>
                <div class="isotope-products">
                    <?php
                    while(have_posts() ) : the_post(); 
                        get_template_part( 'content', get_post_format() ); 
                    endwhile; 
                    ?>
                </div>
                <div class="col-sm-12">
                    <div class="load-more-wrapper text-center"></div>
                </div>
            <?php 
                get_template_part('lib/pagination');
            endif;
            wp_reset_query(); 
            ?>
        </div>
    </div>
</section>
<?php get_footer();?>