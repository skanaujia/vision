<?php
$video = get_post_meta($post->ID, '_single_video', true);
$categories = get_the_category();
$class = '';
if($categories && is_array($categories) ) {
    foreach($categories as $cat) {
        $class .= ' filter-' . $cat->slug;
    }
}
?>
<div class="col-sm-6 <?php echo $class;?>">
    <article <?php post_class('video');?>>
        <figure>
            <?php
            if(isset($GLOBALS['wp_embed']) && $video != '') {
                $embed = $GLOBALS['wp_embed']->autoembed($video);
                $embed = str_replace("feature=oembed", "feature=oembed&amp;wmode=transparent", $embed);
                echo $embed;
            }
            ?>
        </figure>
        <div class="article-content <?php if( $video == '' ) echo 'no-content'?>">
            <h3>
                <a href="<?php the_permalink();?>"><?php the_title();?></a>
            </h3>
            <div class="content">
                <?php echo wp_trim_words(get_the_content(), 14, '...');?>
            </div>
            <a class="read-more" href="<?php the_permalink();?>">
                <?php _e('Read more', 'trendy');?>
            </a>
            <a class="link" href="<?php the_permalink();?>"></a>
        </div>
    </article>
</div>