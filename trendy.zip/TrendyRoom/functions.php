<?php 
add_action( 'after_setup_theme', 'teo_setup' );
if ( ! function_exists( 'teo_setup' ) ){
	function teo_setup(){
		load_theme_textdomain('trendy', get_template_directory() .'/languages');
		//require get_template_directory() . '/teoPanel/redux-framework.php';
		//require get_template_directory() . '/teoPanel/options-config.php';
		require get_template_directory() . '/lib/custom-functions.php';
		require get_template_directory() . '/lib/post_types.php';
		require get_template_directory() . '/lib/widgets.php';
		require get_template_directory() . '/lib/comment.php';
		//require get_template_directory() . '/teoPanel/post_types.php';
		//require get_template_directory() . '/includes/comments.php';
		//require get_template_directory() . '/includes/widgets.php';
		require get_template_directory() . '/lib/meta_boxes.php';
		require get_template_directory() . '/lib/woocommerce.php';
		require get_template_directory() . '/lib/redux/redux-framework.php';
		require get_template_directory() . '/lib/redux-options.php';

		//Post thumbnails support
		add_theme_support( 'post-thumbnails');

		add_theme_support( 'automatic-feed-links' );

		add_theme_support( 'post-formats', array( 'video' ) );

		//Adding custom sidebars
		$args = array(
					'name'          => 'Footer sidebar',
					'before_widget' => '<div id="%1$s" class="col-sm-3 %2$s"><div class="footer-widget">',
					'after_widget'  => '</div></div>',
					'before_title'  => '<h2>',
					'after_title'   => '</h2>' );
		register_sidebar($args);
		
		//Adding a custom menu location
		register_nav_menus( array( 'top-menu' => 'Top primary menu') );
	}
}

add_action('init', 'teo_load');
function teo_load() {
	require get_template_directory() . '/lib/meta_boxes/init.php';
}

// Loading js files into the theme
add_action('wp_enqueue_scripts', 'teo_scripts');
if ( !function_exists('teo_scripts') ) {
	function teo_scripts() {
		wp_enqueue_script( 'jquery');
		wp_enqueue_script( 'jquery-ui-core');
		wp_enqueue_script( 'modernizr-respond.min', get_template_directory_uri() . '/js/modernizr-2.6.2-respond-1.1.0.min.js', '1.0');

		wp_enqueue_script( 'libraries', get_template_directory_uri() . '/js/libraries.js', array('jquery', 'jquery-ui-core', 'jquery-ui-widget', 'jquery-ui-draggable'), '1.0', true);
		wp_enqueue_script( 'main', get_template_directory_uri() . '/js/main.js', array('jquery', 'jquery-ui-core', 'jquery-ui-widget', 'jquery-ui-draggable'), '1.0', true);

		wp_localize_script( 'main', 'MyAjax', array( 'ajaxurl' => admin_url('admin-ajax.php') ) );

		wp_dequeue_script( 'select2' );

		if ( is_singular() && get_option( 'thread_comments' ) )
    		wp_enqueue_script( 'comment-reply' );
	}

}

//Loading the CSS files into the theme
add_action('wp_enqueue_scripts', 'teo_load_css');
if( !function_exists('teo_load_css') ) {
	function teo_load_css() {
		wp_enqueue_style( 'custom', get_template_directory_uri() . '/css/libraries.css', array(), '1.0');
		wp_enqueue_style( 'style', get_stylesheet_directory_uri() . '/style.css', array(), '1.0');

		wp_dequeue_style( 'select2' );
	}
}

function teo_list_pings($comment, $args, $depth) {
		$GLOBALS['comment'] = $comment; ?>
		<li id="comment-<?php comment_ID(); ?>"><?php comment_author_link(); ?> - <?php comment_excerpt(); ?>
	<?php 
}
if ( ! isset( $content_width ) ) $content_width = 990;

/**
 * Render custom language switcher when WPML is installed and active
 */
function teo_language_switcher(){
	
	if( function_exists( 'icl_get_languages' ) ) {
		
	    $languages = icl_get_languages('skip_missing=0&orderby=code');
		
	    if( ! empty( $languages ) ) {
			
			$active		= "";
			$inactives	= array();
			
			// search for active language
			if( is_array( $languages ) ) {
				foreach( $languages as $lang ) {
					if( $lang['active'] ) {
						$active = $lang;
					} else {
						$inactives[] = $lang;
					}
				}
			} 
			
			?>
			<div class="btn-group language-selector">
				<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
					<?php echo '<img src="'.$active['country_flag_url'].'" style="width: 16px; height: 13px" alt="'.$active['language_code'].'" /> ';
					echo $active['native_name']; ?>
					<span class="caret"></span>
				</button>
				<?php if( $inactives ): ?>
				<ul class="dropdown-menu" role="menu">
					<?php foreach( $inactives as $l ): ?>
					<li><a href="<?php echo $l['url']; ?>">  <?php echo '<img style="width: 16px; height: 13px" src="'.$l['country_flag_url'].'" alt="'.$l['language_code'].'" /> ';
					echo $l['native_name']; ?></a></li>
					<?php endforeach; ?>
				</ul>
				<?php endif; ?>
			</div><?php	
	    }

	}
}

/**
 * Check if woocommerce plugin is installed and activated
 * by checking woocommerce class existence
 * 
 * @return boolean
 */
function teo_is_woo_active() {
	return class_exists( 'woocommerce' ) ? true : false;
}

// Ensure cart contents update when products are added to the cart via AJAX (place the following in functions.php)
add_filter('add_to_cart_fragments', 'teo_header_add_to_cart_fragment');
 
function teo_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;
	
	ob_start();
	
	?>
	<div class="cart-info">
		<a href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'trendy'); ?>">
	        <span class="counter"><?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'trendy'), $woocommerce->cart->cart_contents_count);?></span>
	        <span class="separator">/</span>
	        <span class="value"><?php echo $woocommerce->cart->get_cart_total(); ?></span>
	    </a>
    </div>
	<?php
	
	$fragments['.cart-info'] = ob_get_clean();
	
	return $fragments;
	
}

function teo_load_adminscripts() {
 	echo '<script type="text/javascript">
 		jQuery(document).ready(function(){
				var _custom_media = true;
				var _orig_send_attachment = wp.media.editor.send.attachment;

				jQuery("body").on("click", ".select-img", function(e) {
					var send_attachment_bkp = wp.media.editor.send.attachment;
					var button = jQuery(this);
					var id = jQuery(this).data("update-id");
					_custom_media = true;
					wp.media.editor.send.attachment = function(props, attachment) {
						if (_custom_media) {
							jQuery("#" + id).val(attachment.url);
						} else {
							return _orig_send_attachment.apply(this, [props, attachment]);
						}
					}

					wp.media.editor.open(button);
					return false;
				});
		});
 	</script>';
 	global $pagenow;
 	if(in_array( $pagenow, array('post.php', 'post-new.php' ) ) ) {
		echo '
		<script type="text/javascript">
			jQuery(document).ready(function(){
				function meta_hide() {
					jQuery("#imagepost_metabox").hide();
					jQuery("#quotepost_metabox").hide();
					jQuery("#videopost_metabox").hide();
					jQuery("#sliderpost_metabox").hide();
					jQuery("#audiopost_metabox").hide();
				}
				function meta_format(ptval) {
					meta_hide();	
					if(ptval == "quote") {
						jQuery("#quotepost_metabox").show();
					}
					else if(ptval == "gallery") {
						jQuery("#sliderpost_metabox").show();
					}
					else if(ptval == "video") {
						jQuery("#videopost_metabox").show();
					}
					else if(ptval == "audio") {
						jQuery("#audiopost_metabox").show();
					}
					else if(ptval == "image" || ptval == 0) {
						jQuery("#imagepost_metabox").show();
					}
				}
				var post_format = jQuery("input.post-format");
				var post_format_checked = jQuery("input.post-format:checked");
				meta_format(post_format_checked.val());

				post_format.on("change", function() {				
					var ptval = jQuery(this).val();
					meta_format(ptval);
				});
			});
		</script>';
	}
}
add_action('admin_print_scripts', 'teo_load_adminscripts', 1000);

add_action('wp_head', 'teo_customization');
//This function handles the Colorization tab of the theme options
if(! function_exists('teo_customization'))
{
	function teo_customization() {
		//favicon
		global $teo_data;

		if(isset($teo_data['favicon']['url']) && $teo_data['favicon']['url'] != '') {
			echo '<link rel="shortcut icon" href="' . $teo_data['favicon']['url'] . '" />';
			echo '<link rel="apple-touch-icon" href="' . $teo_data['favicon']['url'] . '" />';
		}
	}
}

add_action('wp_enqueue_scripts', 'teo_custom_css', 11);
function teo_custom_css() {
	global $teo_data;
	if(isset($teo_data['custom-css']) && $teo_data['custom-css'] != '') {
		wp_add_inline_style( 'style', $teo_data['custom-css'] );
	}
}

?>