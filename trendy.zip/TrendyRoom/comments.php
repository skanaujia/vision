<?php
/**
 * The template for displaying Comments
 *
 * The area of the page that contains comments and the comment form.
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

/*
 * If the current post is protected by a password and the visitor has not yet
 * entered the password we will return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<?php if ( have_comments() ) : ?>
	<div class="comments">

	<h3 class="comments-title">
		<?php
			printf( _n( 'One comment', '%1$s comments', get_comments_number(), 'trendy' ),
				number_format_i18n( get_comments_number() ) );
		?>
	</h3>

	<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
	<nav id="comment-nav-above" class="navigation comment-navigation" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Comment navigation', 'trendy' ); ?></h1>
		<div class="nav-previous"><?php previous_comments_link( __( '&larr; Older Comments', 'trendy' ) ); ?></div>
		<div class="nav-next"><?php next_comments_link( __( 'Newer Comments &rarr;', 'trendy' ) ); ?></div>
	</nav><!-- #comment-nav-above -->
	<?php endif; // Check for comment navigation. ?>

	<ul>
		<?php wp_list_comments( array(
			'style'      => 'ul',
			'short_ping' => true,
			'avatar_size'=> 34,
			'format' => 'html5',
			'callback' => 'teo_comment'
		) );
		?>
	</ul>

	<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
	<nav id="comment-nav-below" class="navigation comment-navigation" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Comment navigation', 'trendy' ); ?></h1>
		<div class="nav-previous"><?php previous_comments_link( __( '&larr; Older Comments', 'trendy' ) ); ?></div>
		<div class="nav-next"><?php next_comments_link( __( 'Newer Comments &rarr;', 'trendy' ) ); ?></div>
	</nav><!-- #comment-nav-below -->
	<?php endif; // Check for comment navigation. ?>

	<?php if ( ! comments_open() ) : ?>
		<p class="no-comments"><?php _e( 'Comments are closed.', 'trendy' ); ?></p>
	<?php endif; ?>

	</div>

	<?php endif; // have_comments() ?>

	<?php if ('open' == $post->comment_status) : ?>
		<div class="write-comments">
			<?php 
			$commenter = wp_get_current_commenter();
			$req = get_option( 'require_name_email' );
			$aria_req = ( $req ? " aria-required='true'" : '' );
			if($commenter['comment_author'] != '') 
				$name = esc_attr($commenter['comment_author']);
			else 
				$name = '';
			if($commenter['comment_author_email'] != '') 
				$email = esc_attr($commenter['comment_author_email']);
			else
				$email = '';
			if($commenter['comment_author_url'] != '') 
				$url = esc_attr($commenter['comment_author_url']);
			else 
				$url = '';
			$fields =  array(
			'author' => '
				<div class="col-sm-6">
					<label for="author">' . __('Name:', 'trendy') . '</label>
					<input id="author" class="form-control" name="author" type="text" value="' . $name . '" ' . $aria_req . ' />',
			'email'  => '
				<label for="email">' . __('E-mail:', 'trendy') . '</label>
				<input id="email" class="form-control" name="email" type="email" value="' . $email . '" ' . $aria_req . ' />',
			'url'    => '
				<label for="url">' . __('Website:', 'trendy') . '</label>
				<input id="url" class="form-control" name="url" type="url" value="' . $url . '" size="30" />
				</div>
				<div class="col-sm-6">'
			); 
			if(is_user_logged_in() ) {
				$comment_textarea = '
				<div class="col-sm-12">
					<textarea id="comment" name="comment" aria-required="true" class="form-control"></textarea>
				</div>';
			}
			else {
				$comment_textarea = '
					<textarea id="comment" name="comment" aria-required="true" class="form-control"></textarea>
				</div>';
			}
			comment_form( array( 'fields' => $fields, 'comment_field' => $comment_textarea, 'label_submit' => esc_attr__( 'Submit Comment', 'trendy' ), 'title_reply' => '<span>' . esc_attr__( 'Leave a Reply', 'trendy' ) . '</span>', 'title_reply_to' => esc_attr__( 'Leave a Reply to %s', 'trendy' ), 'comment_notes_after' => '') ); ?>

		</div>

	<?php endif; // if you delete this the sky will fall on your head ?>